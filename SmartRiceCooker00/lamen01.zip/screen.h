void gotoxy(int , int );
void text_color(unsigned short ,  unsigned short );
void cursor(int);
