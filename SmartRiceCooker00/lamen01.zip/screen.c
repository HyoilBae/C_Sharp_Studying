#include <windows.h>

// Note: Ŀ�� �̵�
void gotoxy(int x, int y)
{
	COORD CursorPosition = { x, y };
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), 
		                     CursorPosition);
}

// Note: �ؽ�Ʈ ����� ���� ���
void text_color(unsigned short text_color, 
	     unsigned short bk_color)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 
		                    text_color | bk_color << 4);
}

// Ŀ�� ���ֱ�
void cursor(int flag)
{
	CONSOLE_CURSOR_INFO CursorInfo = { 0, };
	CursorInfo.dwSize = 1;
	CursorInfo.bVisible = flag;
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &CursorInfo);
}




